package BookRental;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface DeliveryManagementRepository extends PagingAndSortingRepository<DeliveryManagement, Long>{


}