package BookRental;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface RentalManagementRepository extends PagingAndSortingRepository<RentalManagement, Long>{


}